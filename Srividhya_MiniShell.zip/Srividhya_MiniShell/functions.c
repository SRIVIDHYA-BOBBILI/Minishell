#include "main.h"

#define RESET   "\033[0m"
#define BOLD    "\033[1m"
#define RED     "\033[0;31m"
#define GREEN   "\033[0;32m"
#define YELLOW  "\033[0;33m"
#define BLUE    "\033[0;34m"
#define CYAN    "\033[0;36m"

extern char prompt[20];
extern char input_string[50];
extern char *ext_cmd[200];
int status;
pid_t c1;


// Extract external commands
void extract_external_commands(char **ext_cmd){

    int fd=open("external_cmd.txt",O_RDONLY);
    if(fd < 0) {
        perror("open");
        return;
    }

    char ch,buf[100];
    int i=0,count=0;

    while (read(fd,&ch,1)!=0)
    {
        if (ch == '\r')
            continue;

        if(ch=='\n'){
            buf[i]='\0';

            ext_cmd[count]=malloc(strlen(buf)+1);
            strcpy(ext_cmd[count],buf);

            count++;
            i=0;
        }
        else{
            buf[i]=ch;
            i++;
        }

        ext_cmd[count] = NULL; 
    }
}


// Main shell loop
void scan_input(char *prompt, char *input_string){
    while (1)
    {
        // 🔹 Colored prompt
        printf(GREEN BOLD "%s" RESET, prompt);
        fflush(stdout);

        input_string[0]='\0';
        scanf("%[^\n]",input_string);
        getchar();

        if(input_string[0] == '\0')
            continue;

        // PS1 handling
        if(strstr(input_string,"PS1")){
            if(strchr(input_string,' ')){
                printf(RED "Invalid PS1 input -> %s\n" RESET,input_string);
            }
            else{
                char *equal = strchr(input_string,'=');
                if(equal)
                    strcpy(prompt,equal+1);
                else
                    printf(RED "Invalid PS1 format %s \n" RESET,input_string);
            }
            continue; 
        }

        // job commands
        if(!strcmp(input_string,"jobs") || !strcmp(input_string,"fg") || !strcmp(input_string,"bg")){
            signal_handler_commands(input_string);
            continue;
        }

        char *cmd=get_command(input_string);
        int cmd_type=check_command_type(cmd);
        free(cmd);

        if(cmd_type==BUILTIN){
            execute_internal_commands(input_string);
        }
        else if(cmd_type==EXTERNAL){

            c1=fork();

            if(c1 > 0){
                waitpid(c1,&status,WUNTRACED);
            }
            else if(c1==0){
                signal(SIGINT, SIG_DFL);
                signal(SIGTSTP, SIG_DFL);
                execute_external_commands(input_string);
            }
        }
        else{
            // 🔹 Colored error
            printf(RED "Error: %s : command not found\n" RESET,input_string);
        }
    }
}


// Command type check
int check_command_type(char *command){

    char *builtins[] = {"echo", "printf", "read", "cd", "pwd", "pushd", "popd", "dirs", "let", "eval",
						"set", "unset", "export", "declare", "typeset", "readonly", "getopts", "source",
						"exit", "exec", "shopt", "caller", "true", "type", "hash", "bind", "help", NULL};

    for(int i=0;builtins[i]!=NULL;i++)
        if(strcmp(command,builtins[i])==0){
            return BUILTIN;
        }

    for(int i=0;ext_cmd[i]!=NULL;i++){
        if(strcmp(command ,ext_cmd[i])==0){
            return EXTERNAL;
        }
    }

    return NO_COMMAND;
}


// Extract command
char *get_command(char *input_string){

    char *input=malloc(strlen(input_string)+1);
    strcpy(input,input_string);

    char *space=strchr(input,' ');
    if(space)
        *space='\0';

    return input;
}


// Built-in execution
void execute_internal_commands(char *input_string){

    if(strcmp(input_string,"exit")==0){
        exit(0);
    }

    else if (strcmp(input_string,"pwd")==0){
        char buf[1024];
        getcwd(buf,sizeof(buf));
        printf(BLUE "%s\n" RESET,buf);
    }

    else if(strstr(input_string,"cd")){
        chdir(input_string + 3);
    }

    else if(strstr(input_string,"echo ")){

        if(strcmp(input_string,"echo $$")==0){
            printf(CYAN "%d\n" RESET,getpid());
        }

        else if(strcmp(input_string,"echo $SHELL")==0){
            char buf[1024];
            getcwd(buf,sizeof(buf));
            printf(BLUE "%s\n" RESET,buf);
        }

        else if(strcmp(input_string,"echo $?")==0){
            if(WIFEXITED(status))
                printf(YELLOW "Exited normally with status -> %d\n" RESET,WEXITSTATUS(status));
            else 
                printf(RED "Exited abnormally with status -> %d\n" RESET,status);
        }

        else{
            char buf[50];
            char *space = strchr(input_string, ' ');
            strcpy(buf,space+1);
            printf("%s\n",buf);
        }
    }

    else if(strcmp(input_string,"clear")==0){
        system("clear");
    }
}


// External execution
void execute_external_commands(char *input_string)
{
    char temp[50];
    strcpy(temp,input_string);

    char *args[30];
    int i=0,flag=0;

    char *token = strtok(temp, " ");
    while (token != NULL)
    {
        args[i] = token;
        i++;
        token = strtok(NULL, " ");
    }

    args[i] = NULL;
    int argc = i;

    i=0;
    while(args[i]){ 
        if(strcmp(args[i],"|")==0){
            flag=1;
            break;
        }
        i++;
    }

    if(flag){
        n_pipe(argc,args);
    }
    else{
        execvp(args[0], args);

        // 🔹 colored exec error
        printf(RED "exec failed\n" RESET);
        exit(1);
    }
}