/* Documentation
    Name            : B.SRIVIDHYA
    Date            : 06-04-2026
    Description     : MiniShell is a simple command-line interpreter implemented in C that replicates basic functionalities of a Unix/Linux shell.
                      It allows users to execute built-in and external commands, supports piping between multiple commands, and provides job control 
                      features such as foreground (fg), background (bg), and job listing (jobs). The shell uses system calls like fork(), execvp(), 
                      pipe(), and signal handling mechanisms to manage process execution efficiently. 
*/
#include "main.h"

// Shell prompt (default value)
char prompt[20]="Minishell:$";

// Buffer to store user input
char input_string[50];

// Array to store external commands (loaded from file)
char *ext_cmd[200];

// Main function (entry point of shell)
int main(){

    // Register custom signal handlers
    // Instead of default behavior, these signals will be handled by signal_handler()
    signal(SIGINT,signal_handler);   // Ctrl + C
    signal(SIGTSTP,signal_handler);  // Ctrl + Z
    signal(SIGCHLD,signal_handler);  // Child process termination

    // Clear the terminal screen at start
    system("clear");

    // Load external commands from file into ext_cmd array
    extract_external_commands(ext_cmd);

    // Start shell loop (takes input and executes commands continuously)
    scan_input(prompt,input_string);
}