#include "main.h"

int job_count;                     // Total number of jobs
#define RUNNING     1
#define STOPPED     0

// Structure to store job details
typedef struct node
{
    int job_no;        // Job number (1,2,3...)
    int status;        // RUNNING or STOPPED
    pid_t pid;         // Process ID
    char *input;       // Command string
    struct node *link; // Pointer to next node
} Slist;

Slist *head = NULL;    // Head of linked list (job list)

// function declarations
void insert_last(Slist **hd, int pid);   // Insert job at end
void delete_last(Slist **hd);            // Delete last job
void print_list(Slist *hd);              // Print all jobs

extern char input_string[50];  // Command entered by user
extern char prompt[20];        // Shell prompt
extern pid_t c1;               // Current process id
extern int status;             // Status returned by waitpid

// Signal handler function
void signal_handler(int signum){

    // Handle Ctrl + C
    if(signum == SIGINT){
        // If no command is running, just print prompt
        if(input_string[0]=='\0'){
            printf("\n%s",prompt);
            fflush(stdout);
        }
    }

    // Handle Ctrl + Z (stop process)
    else if(signum == SIGTSTP){
        if(input_string[0]=='\0'){
            // If no command, just print prompt
            printf("\n%s",prompt);
            fflush(stdout);
        }
        else{
            int already_exists = 0;
            Slist *temp = head;

            // Check if process already exists in job list
            while(temp){
                if(temp->pid == c1){
                    already_exists = 1;
                    temp->status = STOPPED;   // Update status
                    printf("[%d]    stopped     %s\n",temp->job_no,input_string);
                    break;
                }
                temp=temp->link;
            }

            // If not found, insert new job
            if (!already_exists){
                insert_last(&head,c1);
                printf("[%d]+   Stopped %s\n",job_count,input_string);
            }
        }
    }

    // Handle child process termination
    else if(signum ==SIGCHLD){
        pid_t complete;

        // Loop to handle all terminated child processes
        while((complete = waitpid(-1,&status,WNOHANG))>0){
            Slist *temp =head;

            // Find the job with matching PID
            while(temp){
                if(temp->pid == complete){
                    printf("[%d]    done %s\n",temp->job_no,temp->input);
                    printf("%s",prompt);
                    fflush(stdout);
                    break;
                }
                temp=temp->link;
            }

            // Delete last job from list
            delete_last(&head);
        }
        
    }    
}

// Function to handle built-in commands: fg, bg, jobs
void signal_handler_commands(char *input_string){

    // Foreground command
    if(strcmp(input_string,"fg")==0){
        int id;

        // If no jobs available
        if(head==NULL){
            printf("--bash : fg : current : no such job\n");
            return;
        }

        Slist *temp=head;

        // If only one job
        if(temp->link==NULL){
            id =temp->pid;
            strcpy(input_string,temp->input); // Copy command
            printf("%s",temp->input);
        }
        else{
            // Move to second last node
            while(temp->link->link){
                temp=temp->link;
            }
            id = temp->link->pid;
            strcpy(input_string,temp->link->input);
            printf("%s\n",temp->link->input);
        }

        c1 = id;

        // Resume process
        kill(id,SIGCONT);

        // Wait for process (foreground execution)
        waitpid(id,&status,WUNTRACED);

        // If process is not stopped again, remove it
        if(!WIFSTOPPED(status)){
            delete_last(&head);
        }
    }

    // Background command
    else if(strcmp(input_string,"bg")==0){
        int id;

        // If no jobs available
        if(head== NULL){
            printf("-bash : bg :current : no such job\n");
            return;
        }

        Slist *temp=head;

        // If only one job
        if(temp->link==NULL){
            id = temp->pid;
            temp->status = RUNNING;  // Update status
            printf("[%d] %s &\n",temp->job_no,temp->input);
        }
        else{
            // Move to second last node
            while(temp->link->link){
                temp=temp->link;
            }
            id=temp->link->pid;
            temp->link->status = RUNNING;
            printf("[%d]    %s  &\n",temp->link->job_no,temp->link->input);
        }

        // Resume process in background
        kill(id,SIGCONT);

        // Re-register SIGCHLD handler
        signal(SIGCHLD,signal_handler);
    }

    // Jobs command
    else if(strcmp(input_string,"jobs")==0){
        print_list(head);  // Print all jobs
    }
}

// Function to print job list
void print_list(Slist *hd){
    if(hd ==NULL){
        // If list is empty, do nothing (like bash)
    }
    else{
        while(hd){
            if(hd->status == RUNNING)
                printf("[%d] Running       %s &\n",hd->job_no,hd->input);
            else
                printf("[%d]    Stopped         %s &\n",hd->job_no,hd->input);

            hd= hd->link;
        }
    }
}

// Insert job at end of list
void insert_last(Slist **hd,int pid){
    Slist *new= malloc(sizeof(Slist));   // Allocate memory

    new->pid = pid;                     // Store process ID
    ++job_count;                        // Increment job count
    new->job_no = job_count;            // Assign job number
    new->status = STOPPED;              // Default status

    // Allocate memory for input command
    new->input = malloc(strlen(input_string)+1);
    strcpy(new->input,input_string);    // Copy command

    new->link =NULL;                    // Last node

    // If list is empty
    if(*hd ==NULL){
        *hd = new;
    }
    else{
        Slist *temp =*hd;

        // Traverse to last node
        while(temp->link !=NULL){
            temp=temp->link;
        }

        temp->link=new;  // Attach new node
    }
}

// Delete last job from list
void delete_last(Slist **hd){
    if(*hd==NULL){
        return;   // Empty list
    }

    Slist *temp=(*hd);

    // If only one node
    if(temp->link==NULL){
        free(temp);
        *hd=NULL;
        job_count =0;   // Reset job count
        return;
    }

    // Traverse to second last node
    while(temp->link->link){
        temp=temp->link;
    }

    free(temp->link);   // Free last node
    temp->link=NULL;    // Remove link
}