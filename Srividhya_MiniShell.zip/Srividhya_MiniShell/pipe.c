#include "main.h"

// Function to handle multiple pipes (command1 | command2 | command3 ...)
int n_pipe(int argc,char *argv[]){

    // Validate arguments (at least one command and one pipe needed)
    if (argc < 3){
        printf("Usage: %s command [args]\n", argv[0]);
        return 1;
    }

    // Array to store starting index of each command
    int arr[argc];
    int j=0,count=1;

    // First command always starts at index 0
    arr[j]=0;
    j++;

    // Identify positions of '|' and split commands
    for(int i=0;i<argc;i++){
        if(strcmp(argv[i],"|")==0){
            count++;             // Increase command count
            arr[j]=i+1;          // Next command starts after '|'
            j++;
            argv[i]=NULL;        // Replace '|' with NULL (for execvp)
        }
    }

    // Save original stdin (so we can restore later)
    int restore = dup(0);

    // Loop through each command
    for(int i=0;i<count;i++){

        int fd[2];

        // Create pipe for all commands except last
        if(i<count-1){
            if(pipe(fd)==-1){
                perror("pipe");
                return -1;
            }
        }

        // Create child process
        pid_t c1=fork();

        if(c1>0){      // Parent process

            // If not last command, redirect stdin to read end of pipe
            if(i < count-1){
                close(fd[1]);        // Close write end
                dup2(fd[0], 0);      // Make read end as stdin
                close(fd[0]);        // Close original fd
            }
        }

        if(c1==0){   // Child process

            // If not last command, redirect stdout to write end of pipe
            if(i < count-1){
                close(fd[0]);        // Close read end
                dup2(fd[1], 1);      // Make write end as stdout
                close(fd[1]);        // Close original fd
            }

            // Execute the command
            execvp(argv[arr[i]],argv+arr[i]);

            // If exec fails (optional safety, not changing logic)
            // perror("execvp");
        }
    }

    // Restore original stdin after pipeline execution
    dup2(restore,0);
    close(restore);

    // Wait for all child processes to finish
    for (int i = 0; i < count; i++)
        wait(NULL);

    return 0;
}
